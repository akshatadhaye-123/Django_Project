from django.contrib import admin
from .models import Category,Product,PaymentMaster
from UserApp.models import OrderMaster
# Register your models here.

class CategoryAdmin(admin.ModelAdmin):
    list_display = ("id","category_name")

class Product_Admin(admin.ModelAdmin):
    list_display = ("id", "pname","price","description",
       "size","quantity","image","cat")

class PaymentMasterAdmin(admin.ModelAdmin):#user se entry bhi krke bhi lene hai
    list_display = ("cardno","cvv","expiry","balance")

class OrderMasterAdmin(admin.ModelAdmin):
    list_display = ("id","user","amount","dateOfOrder","details")

admin.site.register(Category, CategoryAdmin)
admin.site.register(Product, Product_Admin)
admin.site.register(PaymentMaster,PaymentMasterAdmin)
admin.site.register(OrderMaster,OrderMasterAdmin)