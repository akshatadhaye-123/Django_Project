from django.urls import path
from . import views

urlpatterns = [
    path('', views.homepage),
    path('login',views.login),
    path('signup',views.signup),
    path('ShowPizzas/<id>',views.ShowPizzas),
    path('ViewDetails/<id>',views.ViewDetails),
    path('ShowAllCartItems',views.ShowAllCartItems),
    path('removeItem',views.removeItem),
    path('signout',views.signout),
    path('addToCart',views.addToCart),
    path('MakePayment',views.MakePayment),
    path('success',views.success),
]
